import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(
    cred,
    {
        "databaseURL": "https://student-and-employee-att-default-rtdb.firebaseio.com/",

    },
)

ref = db.reference(
    "Students"
)  # reference path to our database... will create student directory in the database

data = {
    "50875": {  # id of student which is a key
        "id": "50875",
        "name": "ERMIYAS ZEWDU ASSEFA",
        "password": "123456",
        "dob": "200-10-08",
        "address": "gondar, ethiopia",
        "phone": "0904369076",
        "email": "ermiyas@gmail.com",
        "major": "Computer Science",
        "starting_year": 2021,
        "standing": "G",
        "total_attendance": 4,
        "year": 4,
        "last_attendance_time": "2023-02-21 12:33:10",
        "user type": "student",
    },
}


for key, value in data.items():
    ref.child(key).set(value)